 /******************************************************************************
 *
 * Module: Port
 *
 * File Name: Port_Cfg.h
 *
 * Description: Pre-Compile Configuration Header file for TM4C123GH6PM Microcontroller - Port Driver
 *
 * Author: Amr Hassan
 ******************************************************************************/

#ifndef PORT_CFG_H
#define PORT_CFG_H

/*
 * Module Version 1.0.0
 */
#define PORT_CFG_SW_MAJOR_VERSION              (1U)
#define PORT_CFG_SW_MINOR_VERSION              (0U)
#define PORT_CFG_SW_PATCH_VERSION              (0U)

/*
 * AUTOSAR Version 4.0.3
 */
#define PORT_CFG_AR_RELEASE_MAJOR_VERSION     (4U)
#define PORT_CFG_AR_RELEASE_MINOR_VERSION     (0U)
#define PORT_CFG_AR_RELEASE_PATCH_VERSION     (3U)

/* Pre-compile option for Development Error Detect */
#define PORT_DEV_ERROR_DETECT                (STD_ON)

/* Pre-compile option for presence of Port_SetPinMode API  */
#define PORT_SET_PIN_MODE_API           (STD_ON)

/* Pre-compile option for presence of Port_SetPinDirection API  */
#define PORT_SET_PIN_DIRECTION_API           (STD_ON)

/* Pre-compile option for Version Info API */
#define PORT_VERSION_INFO_API                (STD_ON)


/* Number of the configured Pin */
#define PORT_CONFIGURED_PORTPINS             (43U)


/* Configuration For LED1 */

/* Configuration For SW1 */
/*******************************************************************************
 *                                  Pin Mode                                   *
 *******************************************************************************/

#define  PORT_PIN_MODE_ADC         (0U)
#define  PORT_PIN_MODE_UART        (1U)
#define  PORT_PIN_MODE_SSI         (2U)
#define  PORT_PIN_MODE_UART1       (2U)
#define  PORT_PIN_MODE_I2C         (3U)
#define  PORT_PIN_MODE_CAN0        (3U)
#define  PORT_PIN_MODE_PWM0        (4U)
#define  PORT_PIN_MODE_PWM1        (5U)
#define  PORT_PIN_MODE_QEI         (6U)
#define  PORT_PIN_MODE_GPT         (7U)
#define  PORT_PIN_MODE_CAN         (8U)
#define  PORT_PIN_MODE_USB         (8U)
#define  PORT_PIN_NOT_ACTIVE       (9U)
#define  PORT_PIN_MODE_DIO         (10U)

   
/* Possible Pin Direction */
//#define PORT_PIN_IN                        STD_LOW
//#define PORT_PIN_OUT                       STD_HIGH
   
/* Possible Pin Level */
#define PORT_PIN_LEVEL_LOW                 STD_LOW
#define PORT_PIN_LEVEL_HIGH                STD_HIGH   
   
/* Configuration of symbolic names of PortPins */
   /*
#define PORT_A_PIN_0_ID                    (uint8)0
#define PORT_A_PIN_1_ID                    (uint8)1
#define PORT_A_PIN_2_ID                    (uint8)2
#define PORT_A_PIN_3_ID                    (uint8)3
#define PORT_A_PIN_4_ID                    (uint8)4
#define PORT_A_PIN_5_ID                    (uint8)5
#define PORT_A_PIN_6_ID                    (uint8)6
#define PORT_A_PIN_7_ID                    (uint8)7
#define PORT_B_PIN_0_ID                    (uint8)8
#define PORT_B_PIN_1_ID                    (uint8)9
#define PORT_B_PIN_2_ID                    (uint8)10
#define PORT_B_PIN_3_ID                    (uint8)11
#define PORT_B_PIN_4_ID                    (uint8)12
#define PORT_B_PIN_5_ID                    (uint8)13
#define PORT_B_PIN_6_ID                    (uint8)14
#define PORT_B_PIN_7_ID                    (uint8)15
#define PORT_C_PIN_0_ID                    (uint8)16
#define PORT_C_PIN_1_ID                    (uint8)17
#define PORT_C_PIN_2_ID                    (uint8)18
#define PORT_C_PIN_3_ID                    (uint8)19
#define PORT_C_PIN_4_ID                    (uint8)20
#define PORT_C_PIN_5_ID                    (uint8)21
#define PORT_C_PIN_6_ID                    (uint8)22
#define PORT_C_PIN_7_ID                    (uint8)23
#define PORT_D_PIN_0_ID                    (uint8)24
#define PORT_D_PIN_1_ID                    (uint8)25
#define PORT_D_PIN_2_ID                    (uint8)26
#define PORT_D_PIN_3_ID                    (uint8)27
#define PORT_D_PIN_4_ID                    (uint8)28
#define PORT_D_PIN_5_ID                    (uint8)29
#define PORT_D_PIN_6_ID                    (uint8)30
#define PORT_D_PIN_7_ID                    (uint8)31
#define PORT_E_PIN_0_ID                    (uint8)32
#define PORT_E_PIN_1_ID                    (uint8)33
#define PORT_E_PIN_2_ID                    (uint8)34
#define PORT_E_PIN_3_ID                    (uint8)35
#define PORT_E_PIN_4_ID                    (uint8)36
#define PORT_E_PIN_5_ID                    (uint8)37
#define PORT_F_PIN_0_ID                    (uint8)38
#define PORT_F_PIN_1_ID                    (uint8)39
#define PORT_F_PIN_2_ID                    (uint8)40
#define PORT_F_PIN_3_ID                    (uint8)41
#define PORT_F_PIN_4_ID                    (uint8)42
*/
# define PORT_PortA_ID                         (0U)
# define PORT_PortB_ID                         (1U)
# define PORT_PortC_ID                         (2U)
# define PORT_PortD_ID                         (3U)
# define PORT_PortE_ID                         (4U)
# define PORT_PortF_ID                         (5U)
   
#define Port_Pin0_ID                           (0U)
#define Port_Pin1_ID                           (1U)
#define Port_Pin2_ID                           (2U)
#define Port_Pin3_ID                           (3U)
#define Port_Pin4_ID                           (4U)
#define Port_Pin5_ID                           (5U)
#define Port_Pin6_ID                           (6U)
#define Port_Pin7_ID                           (7U)




#endif /* PORT_CFG_H */
